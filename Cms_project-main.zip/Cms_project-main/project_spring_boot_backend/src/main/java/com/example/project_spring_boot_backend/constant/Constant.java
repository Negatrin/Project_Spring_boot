package com.example.project_spring_boot_backend.constant;

public class Constant {
    public static final String PHOTO_DIRECTORY = System.getProperty("user.home") + "/Downloads/uploads/";


    public static final String X_REQUESTED_WITH = "X-Requested-With";

}
