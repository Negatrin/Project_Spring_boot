package com.example.project_spring_boot_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSpringBootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
